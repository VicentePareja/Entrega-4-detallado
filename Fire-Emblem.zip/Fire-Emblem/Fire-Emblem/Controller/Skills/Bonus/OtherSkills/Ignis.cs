namespace Fire_Emblem {
    public class Ignis : Skill {
        private double Bonus { get; set; }

        public Ignis(string name, string description) : base(name, description) {
            Bonus = 0.5;
        }

        public override void ApplyEffect(Battle battle, Character owner) {
            Combat combat = battle.CurrentCombat;
            int bonusAtk = Convert.ToInt32(Math.Floor(owner.Atk * Bonus));
            owner.AddTemporaryFirstAttackBonuses("Atk", bonusAtk);
        }
    }
}